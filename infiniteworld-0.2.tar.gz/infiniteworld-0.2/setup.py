from setuptools import setup, find_packages

setup(
    name="infiniteworld",
    version="0.2",
    packages=find_packages(),
    install_requires=["numpy"],
    author="Agent11",
    description="Infinite chunk procedural generation system",
)
