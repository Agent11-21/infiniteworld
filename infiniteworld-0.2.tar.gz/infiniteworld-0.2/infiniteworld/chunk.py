import numpy as np

TAILLE = 64

def generate_chunk(chunk_x, chunk_y, world_seed, border_noise_fn):

    rng = np.random.default_rng(seed=None)  # vraiment aléatoire

    chunk = np.zeros((TAILLE, TAILLE), dtype=np.int16)

    for y in range(TAILLE):
        for x in range(TAILLE):

            voisins = []

            if x > 0:
                voisins.append(int(chunk[y, x - 1]))
            else:
                voisins.append(border_noise_fn(chunk_x * TAILLE - 1, chunk_y * TAILLE + y))

            if y > 0:
                voisins.append(int(chunk[y - 1, x]))
            else:
                voisins.append(border_noise_fn(chunk_x * TAILLE + x, chunk_y * TAILLE - 1))

            moyenne = sum(voisins) / len(voisins)
            variation = int(rng.integers(-3, 4))
            valeur = int(np.clip(moyenne + variation, 0, 100))
            chunk[y, x] = valeur

    return chunk
