import random
from .chunk import generate_chunk
from .storage import save_chunk, load_chunk

class World:

    def __init__(self):
        self.loaded_chunks = {}
        self._world_seed = random.randint(0, 10**9)
        self._border_cache = {}

    def _border_noise(self, x, y):
        key = (x, y)
        if key not in self._border_cache:
            rng = random.Random(self._world_seed ^ hash(key))
            self._border_cache[key] = rng.randint(0, 100)
        return self._border_cache[key]

    def get_chunk(self, x, y):
        key = (x, y)

        if key in self.loaded_chunks:
            return self.loaded_chunks[key]

        chunk = load_chunk(x, y)

        if chunk is None:
            chunk = generate_chunk(x, y, self._world_seed, self._border_noise)
            save_chunk(x, y, chunk)

        self.loaded_chunks[key] = chunk
        return chunk

    def preload_around(self, cx, cy, radius=2):
        for dx in range(-radius, radius + 1):
            for dy in range(-radius, radius + 1):
                self.get_chunk(cx + dx, cy + dy)

    def unload_far_chunks(self, cx, cy, distance=5):
        to_remove = [
            (x, y) for (x, y) in self.loaded_chunks
            if abs(x - cx) > distance or abs(y - cy) > distance
        ]
        for key in to_remove:
            del self.loaded_chunks[key]
