import numpy as np
import os

DOSSIER = "world_chunks"

os.makedirs(DOSSIER, exist_ok=True)

def chunk_path(x, y):
    return f"{DOSSIER}/chunk_{x}_{y}.npy"

def save_chunk(x, y, chunk):
    np.save(chunk_path(x, y), np.array(chunk, dtype=np.uint8))

def load_chunk(x, y):
    path = chunk_path(x, y)
    if not os.path.exists(path):
        return None
    return np.load(path)
